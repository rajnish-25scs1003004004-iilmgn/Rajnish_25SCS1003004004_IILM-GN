# Installation Guide
## Wildlife Distribution Map Storage System

**Course:** CSE-UCS-1002 - Introduction to AI-ML  
**Project:** AI-Enhanced Wildlife Corridor Identification and Prediction  
**Version:** 1.0  
**Last Updated:** October 2025  

---

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Installation Steps](#installation-steps)
3. [Configuration](#configuration)
4. [Verification](#verification)
5. [Troubleshooting](#troubleshooting)
6. [Usage Examples](#usage-examples)

---

## System Requirements

### Software Requirements

#### Python Environment
- **Python:** Version 3.8 or higher
- **Operating System:** Windows 10+, macOS 10.14+, or Linux (Ubuntu 18.04+)
- **Memory:** Minimum 4GB RAM (8GB recommended)
- **Storage:** At least 1GB free space for installation and data

#### Required Python Packages
```bash
pandas>=1.3.0          # Data manipulation and analysis
numpy>=1.20.0           # Numerical computing
matplotlib>=3.3.0       # Plotting and visualization
seaborn>=0.11.0         # Statistical data visualization
sqlite3                 # Database (built-in with Python)
pathlib                 # Path manipulation (built-in with Python 3.4+)
uuid                    # UUID generation (built-in)
hashlib                 # File hashing (built-in)
json                    # JSON handling (built-in)
datetime                # Date/time handling (built-in)
```

#### Optional Packages (for advanced features)
```bash
geopandas>=0.9.0        # Geospatial data handling
rasterio>=1.2.0         # Raster data I/O
folium>=0.12.0          # Interactive maps
plotly>=5.0.0           # Interactive visualizations
```

### Hardware Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **CPU** | Dual-core 2.0 GHz | Quad-core 2.5 GHz+ |
| **RAM** | 4 GB | 8 GB+ |
| **Storage** | 1 GB available | 5 GB+ available |
| **Network** | Not required | Internet for package installation |

---

## Installation Steps

### Step 1: Verify Python Installation

```bash
# Check Python version
python --version
# or
python3 --version

# Expected output: Python 3.8.x or higher
```

If Python is not installed or version is too old:
- **Windows:** Download from [python.org](https://python.org)
- **macOS:** Use Homebrew: `brew install python`
- **Linux:** Use package manager: `sudo apt update && sudo apt install python3 python3-pip`

### Step 2: Download Project Files

#### Option A: Direct Download
1. Download the project files to your desired directory
2. Extract if compressed
3. Navigate to the project directory

#### Option B: Clone Repository (if available)
```bash
git clone <repository-url>
cd wildlife_corridor_project
```

### Step 3: Create Virtual Environment (Recommended)

```bash
# Create virtual environment
python -m venv wildlife_env

# Activate virtual environment
# On Windows:
wildlife_env\Scripts\activate

# On macOS/Linux:
source wildlife_env/bin/activate

# Verify activation (you should see (wildlife_env) in your prompt)
```

### Step 4: Install Required Packages

#### Basic Installation
```bash
# Upgrade pip first
pip install --upgrade pip

# Install core requirements
pip install pandas numpy matplotlib seaborn

# Alternative: Install from requirements file (if available)
pip install -r requirements.txt
```

#### Advanced Installation (with GIS support)
```bash
# Install additional geospatial packages
pip install geopandas rasterio folium plotly

# Note: On some systems, you may need system dependencies for geopandas
# Ubuntu/Debian:
sudo apt-get install gdal-bin libgdal-dev

# macOS with Homebrew:
brew install gdal
```

### Step 5: Verify Installation

```bash
# Navigate to project directory
cd wildlife_corridor_project

# Run verification script
python -c "import pandas, numpy, matplotlib, seaborn; print('All packages imported successfully!')"

# Test the main module
cd src
python -c "from distribution_map_storage import DistributionMapStorage; print('Main module imported successfully!')"
```

---

## Configuration

### Database Configuration

The system uses SQLite by default, which requires no additional configuration. However, you can customize the database location:

```python
from src.distribution_map_storage import DistributionMapStorage

# Custom database path
storage = DistributionMapStorage(
    db_path="/path/to/your/database.db",      # Custom database location
    storage_root="/path/to/your/map/storage"  # Custom file storage location
)
```

### Environment Variables (Optional)

Create a `.env` file in the project root for environment-specific settings:

```bash
# .env file
WILDLIFE_DB_PATH=/data/wildlife_maps.db
WILDLIFE_STORAGE_ROOT=/data/map_storage
WILDLIFE_LOG_LEVEL=INFO
```

### Directory Structure Setup

The system will automatically create necessary directories, but you can pre-create them:

```bash
mkdir -p data output docs tests
mkdir -p output/map_storage/{habitat_suitability_maps,presence_probability_maps,corridor_prediction_maps,metadata}
```

---

## Verification

### Quick Verification Test

Run this complete verification to ensure everything works:

```bash
cd wildlife_corridor_project/src
python demo_system.py
```

Expected output:
```
🚀 Starting Wildlife Distribution Map Storage System Demo
============================================================

📊 Step 1: Creating sample species...
Added species: African Lion (ID: 1)
Added species: African Elephant (ID: 2)
...

✅ Demo completed successfully!
```

### Manual Verification Steps

1. **Test Database Creation:**
```python
from src.distribution_map_storage import DistributionMapStorage

storage = DistributionMapStorage("test.db", "test_storage")
print("Database created successfully!")
```

2. **Test Species Addition:**
```python
species_id = storage.add_species(
    scientific_name="Panthera leo",
    common_name="African Lion"
)
print(f"Species added with ID: {species_id}")
```

3. **Test Query Operations:**
```python
stats = storage.get_map_statistics()
print(f"Statistics generated: {stats}")
```

### Run Test Suite

```bash
cd tests
python test_storage_system.py
```

Expected output:
```
test_add_species ... ok
test_store_distribution_map ... ok
test_query_maps ... ok
...

Test Summary:
Tests run: 15
Failures: 0
Errors: 0
Success rate: 100.0%
```

---

## Troubleshooting

### Common Issues and Solutions

#### 1. ImportError: No module named 'pandas'

**Problem:** Required packages not installed
**Solution:**
```bash
pip install pandas numpy matplotlib seaborn
```

#### 2. Permission Denied when creating database

**Problem:** Insufficient permissions in target directory
**Solution:**
```bash
# Change to a writable directory
cd ~/Documents
# Or change permissions
chmod 755 /path/to/project/directory
```

#### 3. SQLite Database Locked

**Problem:** Database file is locked by another process
**Solution:**
```bash
# Close all connections to the database
# Or delete the database file to start fresh
rm wildlife_maps.db
```

#### 4. matplotlib backend issues

**Problem:** No display available for matplotlib
**Solution:**
```python
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
```

#### 5. File Path Issues on Windows

**Problem:** Path separators causing issues
**Solution:**
```python
import os
# Use os.path.join() or pathlib
from pathlib import Path
db_path = Path("data") / "wildlife_maps.db"
```

### Platform-Specific Issues

#### Windows
- Use forward slashes in paths or raw strings: `r"C:\path\to\file"`
- May need Visual Studio Build Tools for some packages
- Use PowerShell or Command Prompt as Administrator if needed

#### macOS
- Install Xcode Command Line Tools: `xcode-select --install`
- Use Homebrew for system dependencies
- May need to update PATH for Python

#### Linux
- Install system dependencies: `sudo apt-get install python3-dev`
- Use virtual environments to avoid system package conflicts
- Check file permissions carefully

### Getting Help

If you encounter issues not covered here:

1. **Check Error Messages:** Read the full error message for clues
2. **Verify Dependencies:** Ensure all required packages are installed
3. **Check Python Version:** Confirm Python 3.8+ is being used
4. **Review Documentation:** Check the project documentation
5. **Test in Clean Environment:** Try in a fresh virtual environment

### Debug Mode

Enable debug mode for detailed logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

from src.distribution_map_storage import DistributionMapStorage
# Now all operations will show detailed logs
```

---

## Usage Examples

### Basic Usage Pattern

```python
from src.distribution_map_storage import DistributionMapStorage

# 1. Initialize system
storage = DistributionMapStorage("wildlife.db", "map_storage")

# 2. Add species
species_id = storage.add_species(
    scientific_name="Panthera leo",
    common_name="African Lion",
    conservation_status="Vulnerable"
)

# 3. Store a map (you need an actual CSV file)
map_id = storage.store_distribution_map(
    species_id=species_id,
    map_name="Lion Habitat Suitability - Serengeti",
    map_type="habitat_suitability",
    file_path="path/to/your/map.csv",
    metadata={
        'algorithm': 'MaxEnt',
        'accuracy': 0.89,
        'resolution': 1.0
    }
)

# 4. Query maps
results = storage.query_maps(species_id=species_id)
print(results)

# 5. Get statistics
stats = storage.get_map_statistics()
print(f"Total maps: {stats['total_maps']}")
```

### Advanced Configuration

```python
# Custom configuration
storage = DistributionMapStorage(
    db_path="custom_location/wildlife_database.db",
    storage_root="custom_storage/maps"
)

# Bulk operations
species_list = [
    ("Panthera leo", "African Lion"),
    ("Loxodonta africana", "African Elephant"),
    ("Acinonyx jubatus", "Cheetah")
]

species_mapping = {}
for scientific_name, common_name in species_list:
    species_id = storage.add_species(
        scientific_name=scientific_name,
        common_name=common_name
    )
    species_mapping[scientific_name] = species_id
```

---

## Next Steps

After successful installation:

1. **Read the Documentation:** Review the [project report](project_report.md) and [API documentation](api_documentation.md)
2. **Run Examples:** Try the demo system and example scripts
3. **Explore Features:** Test different query options and visualizations
4. **Customize:** Adapt the system for your specific needs
5. **Contribute:** Add new features or improvements

---

## Support and Resources

### Documentation
- **[Project Report](project_report.md)** - Comprehensive technical documentation
- **[API Documentation](api_documentation.md)** - Detailed API reference
- **[README](../README.md)** - Project overview and quick start

### Course Information
- **Course:** CSE-UCS-1002 - Introduction to AI-ML
- **Instructor:** Dr. Saurabh Shanu
- **Institution:** [Your University]

### Technical Support
For technical issues or questions:
1. Check this installation guide
2. Review error messages carefully
3. Try the troubleshooting section
4. Consult course materials and documentation

---

*This installation guide is part of the Wildlife Distribution Map Storage System project developed for the AI-Enhanced Wildlife Corridor Identification and Prediction course project.*