# API Documentation
## Wildlife Distribution Map Storage System

**Version:** 1.0  
**Last Updated:** October 2025  
**Course:** CSE-UCS-1002 - Introduction to AI-ML  

---

## Table of Contents

1. [Overview](#overview)
2. [Getting Started](#getting-started)
3. [Core Classes](#core-classes)
4. [Method Reference](#method-reference)
5. [Data Models](#data-models)
6. [Error Handling](#error-handling)
7. [Examples](#examples)
8. [Best Practices](#best-practices)

---

## Overview

The Wildlife Distribution Map Storage System provides a comprehensive API for managing species distribution maps in wildlife conservation applications. The system is designed around the `DistributionMapStorage` class, which serves as the primary interface for all database operations.

### Key Features
- **Species Management** - Add, update, and query wildlife species
- **Map Storage** - Store distribution maps with comprehensive metadata
- **Advanced Querying** - Flexible search and filtering capabilities
- **Analytics** - Generate system statistics and reports
- **Data Export** - Export data in multiple formats

---

## Getting Started

### Installation

```python
# Import the main storage class
from distribution_map_storage import DistributionMapStorage

# Initialize the storage system
storage = DistributionMapStorage(
    db_path="wildlife_maps.db",        # SQLite database file
    storage_root="map_storage"         # Directory for map files
)
```

### Basic Workflow

```python
# 1. Add a species
species_id = storage.add_species(
    scientific_name="Panthera leo",
    common_name="African Lion"
)

# 2. Store a distribution map
map_id = storage.store_distribution_map(
    species_id=species_id,
    map_name="Lion Habitat Suitability",
    map_type="habitat_suitability", 
    file_path="maps/lion_habitat.csv",
    metadata={"accuracy": 0.89}
)

# 3. Query maps
results = storage.query_maps(species_id=species_id)

# 4. Get statistics
stats = storage.get_map_statistics()
```

---

## Core Classes

### DistributionMapStorage

The main class providing all storage system functionality.

**Constructor Parameters:**
- `db_path` (str): Path to SQLite database file
- `storage_root` (str): Root directory for storing map files

**Properties:**
- `db_path` (str): Database file path
- `storage_root` (Path): Storage directory path

---

## Method Reference

### Species Management

#### `add_species(scientific_name, common_name=None, family=None, habitat_type=None, conservation_status=None)`

Adds a new species to the database or returns existing species ID.

**Parameters:**
- `scientific_name` (str, required): Scientific name (e.g., "Panthera leo")
- `common_name` (str, optional): Common name (e.g., "African Lion")
- `family` (str, optional): Taxonomic family (e.g., "Felidae")
- `habitat_type` (str, optional): Primary habitat (e.g., "Savanna")
- `conservation_status` (str, optional): IUCN status (e.g., "Vulnerable")

**Returns:**
- `int`: Species ID

**Example:**
```python
species_id = storage.add_species(
    scientific_name="Loxodonta africana",
    common_name="African Elephant",
    family="Elephantidae",
    habitat_type="Savanna/Forest",
    conservation_status="Endangered"
)
```

**Raises:**
- `ValueError`: If scientific_name is empty
- `sqlite3.Error`: If database operation fails

---

### Map Storage

#### `store_distribution_map(species_id, map_name, map_type, file_path, metadata=None)`

Stores a distribution map with associated metadata and file.

**Parameters:**
- `species_id` (int, required): ID of associated species
- `map_name` (str, required): Descriptive name for the map
- `map_type` (str, required): Type of map ("habitat_suitability", "presence_probability", "corridor_prediction")
- `file_path` (str, required): Path to the map file
- `metadata` (dict, optional): Additional metadata dictionary

**Returns:**
- `str`: Unique map ID (UUID)

**Metadata Keys:**
- `algorithm` (str): ML algorithm used (e.g., "MaxEnt", "Random Forest")
- `accuracy` (float): Model accuracy score (0.0-1.0)
- `validation_method` (str): Validation approach (e.g., "Cross-validation")
- `coordinate_system` (str): Spatial reference system (default: "WGS84")
- `resolution` (float): Map resolution in kilometers
- `created_by` (str): Creator identification

**Example:**
```python
map_id = storage.store_distribution_map(
    species_id=1,
    map_name="Cheetah Habitat Suitability - Serengeti",
    map_type="habitat_suitability",
    file_path="/data/cheetah_habitat.csv",
    metadata={
        'algorithm': 'MaxEnt',
        'accuracy': 0.87,
        'validation_method': 'Cross-validation',
        'resolution': 1.0,
        'environmental_variables': ['temperature', 'precipitation', 'elevation'],
        'training_samples': 1250
    }
)
```

**Raises:**
- `FileNotFoundError`: If file_path doesn't exist
- `ValueError`: If species_id is invalid
- `sqlite3.Error`: If database operation fails

---

### Query Operations

#### `query_maps(species_id=None, map_type=None, min_accuracy=None, limit=None)`

Queries distribution maps based on specified criteria.

**Parameters:**
- `species_id` (int, optional): Filter by species ID
- `map_type` (str, optional): Filter by map type
- `min_accuracy` (float, optional): Minimum accuracy threshold
- `limit` (int, optional): Maximum number of results

**Returns:**
- `pandas.DataFrame`: Query results with columns:
  - `map_id`: Unique map identifier
  - `species_id`: Associated species ID
  - `scientific_name`: Species scientific name
  - `common_name`: Species common name
  - `map_name`: Map name
  - `map_type`: Type of map
  - `accuracy_score`: Model accuracy
  - `created_at`: Creation timestamp
  - `file_path`: Path to map file

**Example:**
```python
# Get all habitat suitability maps
habitat_maps = storage.query_maps(map_type="habitat_suitability")

# Get high-accuracy maps for a specific species
accurate_maps = storage.query_maps(
    species_id=1,
    min_accuracy=0.85,
    limit=10
)

# Get recent maps
recent_maps = storage.query_maps(limit=5)
```

---

### Analytics and Statistics

#### `get_map_statistics()`

Generates comprehensive system statistics.

**Returns:**
- `dict`: Statistics dictionary with keys:
  - `total_maps` (int): Total number of active maps
  - `maps_by_type` (list): Count by map type
  - `maps_by_species` (list): Count by species
  - `total_storage_mb` (float): Total storage usage in MB
  - `average_accuracy` (float): Mean accuracy across all maps

**Example:**
```python
stats = storage.get_map_statistics()
print(f"Total maps: {stats['total_maps']}")
print(f"Average accuracy: {stats['average_accuracy']:.3f}")
print(f"Storage usage: {stats['total_storage_mb']} MB")

# Maps by type
for item in stats['maps_by_type']:
    print(f"{item['map_type']}: {item['count']} maps")
```

---

### Data Export

#### `export_metadata(output_path, format='csv')`

Exports system metadata to a file.

**Parameters:**
- `output_path` (str, required): Output file path
- `format` (str, optional): Export format ("csv" or "json")

**Returns:**
- `int`: Number of records exported

**Example:**
```python
# Export to CSV
count = storage.export_metadata("metadata_export.csv", format="csv")
print(f"Exported {count} records")

# Export to JSON
count = storage.export_metadata("metadata_export.json", format="json")
```

---

## Data Models

### Species Model

```python
{
    "species_id": 1,
    "scientific_name": "Panthera leo",
    "common_name": "African Lion",
    "family": "Felidae",
    "habitat_type": "Savanna",
    "conservation_status": "Vulnerable",
    "created_at": "2025-10-03T12:00:00Z",
    "updated_at": "2025-10-03T12:00:00Z"
}
```

### Distribution Map Model

```python
{
    "map_id": "uuid-string",
    "species_id": 1,
    "map_name": "Lion Habitat Suitability - Serengeti",
    "map_type": "habitat_suitability",
    "file_format": "csv",
    "file_path": "/storage/maps/uuid.csv",
    "file_size": 1048576,
    "file_hash": "sha256-hash",
    "spatial_extent": {
        "min_x": -180.0,
        "max_x": 180.0,
        "min_y": -90.0,
        "max_y": 90.0
    },
    "coordinate_system": "WGS84",
    "resolution": 1.0,
    "prediction_algorithm": "MaxEnt",
    "accuracy_score": 0.89,
    "validation_method": "Cross-validation",
    "created_by": "researcher",
    "created_at": "2025-10-03T12:00:00Z",
    "version": 1,
    "status": "active"
}
```

### Map Statistics Model

```python
{
    "total_maps": 25,
    "maps_by_type": [
        {"map_type": "habitat_suitability", "count": 10},
        {"map_type": "presence_probability", "count": 8},
        {"map_type": "corridor_prediction", "count": 7}
    ],
    "maps_by_species": [
        {
            "scientific_name": "Panthera leo",
            "common_name": "African Lion",
            "map_count": 5
        }
    ],
    "total_storage_mb": 156.7,
    "average_accuracy": 0.847
}
```

---

## Error Handling

### Common Exceptions

#### `FileNotFoundError`
Raised when a specified map file doesn't exist.
```python
try:
    map_id = storage.store_distribution_map(
        species_id=1,
        map_name="Test Map",
        map_type="habitat_suitability",
        file_path="nonexistent_file.csv"
    )
except FileNotFoundError as e:
    print(f"Map file not found: {e}")
```

#### `ValueError`
Raised for invalid parameter values.
```python
try:
    species_id = storage.add_species(scientific_name="")
except ValueError as e:
    print(f"Invalid parameter: {e}")
```

#### `sqlite3.Error`
Raised for database operation failures.
```python
import sqlite3

try:
    species_id = storage.add_species(scientific_name="Panthera leo")
except sqlite3.Error as e:
    print(f"Database error: {e}")
```

### Error Response Format

```python
{
    "error": True,
    "error_type": "ValueError",
    "message": "Scientific name cannot be empty",
    "timestamp": "2025-10-03T12:00:00Z"
}
```

---

## Examples

### Complete Workflow Example

```python
from distribution_map_storage import DistributionMapStorage
import pandas as pd

# Initialize storage system
storage = DistributionMapStorage(
    db_path="conservation_project.db",
    storage_root="conservation_maps"
)

# Add multiple species
species_data = [
    {
        'scientific_name': 'Panthera leo',
        'common_name': 'African Lion',
        'family': 'Felidae',
        'conservation_status': 'Vulnerable'
    },
    {
        'scientific_name': 'Loxodonta africana', 
        'common_name': 'African Elephant',
        'family': 'Elephantidae',
        'conservation_status': 'Endangered'
    }
]

species_ids = {}
for species in species_data:
    species_id = storage.add_species(**species)
    species_ids[species['scientific_name']] = species_id

# Store distribution maps
map_metadata = {
    'algorithm': 'Random Forest',
    'accuracy': 0.91,
    'validation_method': 'Spatial cross-validation',
    'resolution': 1.0,
    'created_by': 'Conservation Team',
    'environmental_variables': [
        'annual_temperature',
        'precipitation',
        'elevation',
        'land_cover'
    ]
}

lion_map_id = storage.store_distribution_map(
    species_id=species_ids['Panthera leo'],
    map_name="Lion Habitat Suitability - East Africa",
    map_type="habitat_suitability",
    file_path="maps/lion_habitat_eastafrica.csv",
    metadata=map_metadata
)

# Query and analyze results
all_maps = storage.query_maps()
high_quality_maps = storage.query_maps(min_accuracy=0.85)

print(f"Total maps stored: {len(all_maps)}")
print(f"High quality maps: {len(high_quality_maps)}")

# Generate analytics
stats = storage.get_map_statistics()
print(f"System statistics: {stats}")

# Export data for further analysis
storage.export_metadata("project_metadata.csv")
```

### Batch Operations Example

```python
# Batch species addition
species_list = [
    ("Acinonyx jubatus", "Cheetah", "Felidae", "Vulnerable"),
    ("Diceros bicornis", "Black Rhinoceros", "Rhinocerotidae", "Critically Endangered"),
    ("Giraffa camelopardalis", "Giraffe", "Giraffidae", "Vulnerable")
]

species_mapping = {}
for scientific, common, family, status in species_list:
    species_id = storage.add_species(
        scientific_name=scientific,
        common_name=common,
        family=family,
        conservation_status=status
    )
    species_mapping[scientific] = species_id

print(f"Added {len(species_mapping)} species")
```

### Advanced Query Example

```python
# Complex multi-criteria query
def find_conservation_priority_maps():
    """Find high-quality maps for endangered species."""
    
    # Get all maps
    all_maps = storage.query_maps()
    
    # Filter endangered species with high accuracy
    endangered_status = ['Endangered', 'Critically Endangered']
    priority_maps = all_maps[
        (all_maps['conservation_status'].isin(endangered_status)) &
        (all_maps['accuracy_score'] >= 0.85)
    ]
    
    return priority_maps.sort_values('accuracy_score', ascending=False)

priority_maps = find_conservation_priority_maps()
print(f"Found {len(priority_maps)} priority conservation maps")
```

---

## Best Practices

### 1. Resource Management

```python
# Always close storage connections
try:
    storage = DistributionMapStorage("project.db", "maps")
    # ... perform operations
finally:
    storage.close()

# Or use context manager pattern
class StorageContext:
    def __enter__(self):
        self.storage = DistributionMapStorage("project.db", "maps")
        return self.storage
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.storage.close()

with StorageContext() as storage:
    # ... operations
    pass
```

### 2. Error Handling

```python
import logging

def safe_map_storage(storage, species_id, map_name, map_type, file_path, metadata):
    """Safely store a map with comprehensive error handling."""
    try:
        # Validate inputs
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Map file not found: {file_path}")
        
        if not map_name.strip():
            raise ValueError("Map name cannot be empty")
        
        # Store map
        map_id = storage.store_distribution_map(
            species_id=species_id,
            map_name=map_name,
            map_type=map_type,
            file_path=file_path,
            metadata=metadata
        )
        
        logging.info(f"Successfully stored map: {map_id}")
        return map_id
        
    except FileNotFoundError as e:
        logging.error(f"File error: {e}")
        return None
    except ValueError as e:
        logging.error(f"Validation error: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return None
```

### 3. Performance Optimization

```python
# Batch operations for better performance
def batch_map_storage(storage, map_data_list):
    """Store multiple maps efficiently."""
    stored_maps = []
    
    # Process in batches
    batch_size = 10
    for i in range(0, len(map_data_list), batch_size):
        batch = map_data_list[i:i + batch_size]
        
        for map_data in batch:
            try:
                map_id = storage.store_distribution_map(**map_data)
                stored_maps.append(map_id)
            except Exception as e:
                logging.error(f"Failed to store map: {e}")
                continue
    
    return stored_maps

# Use efficient queries
def get_species_summary():
    """Get efficient species summary."""
    # Single query instead of multiple calls
    stats = storage.get_map_statistics()
    return stats['maps_by_species']
```

### 4. Data Validation

```python
def validate_metadata(metadata):
    """Validate metadata before storage."""
    required_fields = ['algorithm', 'accuracy']
    
    for field in required_fields:
        if field not in metadata:
            raise ValueError(f"Required field missing: {field}")
    
    # Validate accuracy range
    if not 0.0 <= metadata['accuracy'] <= 1.0:
        raise ValueError("Accuracy must be between 0.0 and 1.0")
    
    return True

# Use validation in storage operations
def store_validated_map(storage, **kwargs):
    """Store map with validation."""
    metadata = kwargs.get('metadata', {})
    
    # Validate before storage
    validate_metadata(metadata)
    
    return storage.store_distribution_map(**kwargs)
```

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Oct 2025 | Initial release with core functionality |

---

## Support

For questions or issues:
- **Course:** CSE-UCS-1002 - Introduction to AI-ML
- **Instructor:** Dr. Saurabh Shanu
- **Documentation:** See `docs/` directory for additional resources

---

*This API documentation is part of the Wildlife Distribution Map Storage System project developed for the AI-Enhanced Wildlife Corridor Identification and Prediction course project.*