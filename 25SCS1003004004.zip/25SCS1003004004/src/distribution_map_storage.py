"""
Wildlife Distribution Map Storage System
=====================================

This module provides a comprehensive system for storing, managing, and retrieving
predicted species distribution maps for wildlife corridor identification.

Author: Your Name
Course: CSE-UCS-1002 - Introduction to AI-ML
Project: AI-Enhanced Wildlife Corridor Identification and Prediction
Task: Store Predicted Distribution Maps
"""

import sqlite3
import json
import os
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
import hashlib
import uuid
from pathlib import Path
import shutil


class DistributionMapStorage:
    """
    A comprehensive system for storing and managing species distribution maps.
    
    This class provides functionality to:
    - Store species distribution maps with metadata
    - Manage different map formats (raster, vector, prediction grids)
    - Query and retrieve maps based on various criteria
    - Maintain data integrity and version control
    - Generate statistics and reports
    """
    
    def __init__(self, db_path: str = "wildlife_distribution_maps.db", 
                 storage_root: str = "map_storage"):
        """
        Initialize the Distribution Map Storage System.
        
        Args:
            db_path: Path to SQLite database file
            storage_root: Root directory for storing map files
        """
        self.db_path = db_path
        self.storage_root = Path(storage_root)
        self.storage_root.mkdir(exist_ok=True)
        
        # Create subdirectories for different map types
        (self.storage_root / "raster_maps").mkdir(exist_ok=True)
        (self.storage_root / "vector_maps").mkdir(exist_ok=True)
        (self.storage_root / "prediction_grids").mkdir(exist_ok=True)
        (self.storage_root / "metadata").mkdir(exist_ok=True)
        
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize the database with required tables."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Species table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS species (
                    species_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scientific_name TEXT NOT NULL UNIQUE,
                    common_name TEXT,
                    family TEXT,
                    habitat_type TEXT,
                    conservation_status TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Distribution maps table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS distribution_maps (
                    map_id TEXT PRIMARY KEY,
                    species_id INTEGER,
                    map_name TEXT NOT NULL,
                    map_type TEXT NOT NULL, -- 'habitat_suitability', 'presence_probability', 'corridor_prediction'
                    file_format TEXT NOT NULL, -- 'geotiff', 'shapefile', 'netcdf', 'csv'
                    file_path TEXT NOT NULL,
                    file_size INTEGER,
                    file_hash TEXT,
                    spatial_extent TEXT, -- JSON: {"min_x": , "max_x": , "min_y": , "max_y": }
                    coordinate_system TEXT,
                    resolution REAL,
                    prediction_algorithm TEXT,
                    accuracy_score REAL,
                    validation_method TEXT,
                    created_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    version INTEGER DEFAULT 1,
                    status TEXT DEFAULT 'active', -- 'active', 'archived', 'deprecated'
                    FOREIGN KEY (species_id) REFERENCES species (species_id)
                )
            """)
            
            # Map metadata table for additional attributes
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS map_metadata (
                    metadata_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    map_id TEXT,
                    attribute_name TEXT,
                    attribute_value TEXT,
                    data_type TEXT, -- 'string', 'numeric', 'boolean', 'json'
                    FOREIGN KEY (map_id) REFERENCES distribution_maps (map_id)
                )
            """)
            
            # Environmental variables table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS environmental_variables (
                    var_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    map_id TEXT,
                    variable_name TEXT,
                    variable_type TEXT, -- 'climate', 'topographic', 'land_cover', 'anthropogenic'
                    importance_score REAL,
                    data_source TEXT,
                    FOREIGN KEY (map_id) REFERENCES distribution_maps (map_id)
                )
            """)
            
            # Map relationships table (for corridor connectivity)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS map_relationships (
                    relationship_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_map_id TEXT,
                    target_map_id TEXT,
                    relationship_type TEXT, -- 'corridor', 'barrier', 'stepping_stone'
                    strength REAL, -- 0.0 to 1.0
                    distance_km REAL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (source_map_id) REFERENCES distribution_maps (map_id),
                    FOREIGN KEY (target_map_id) REFERENCES distribution_maps (map_id)
                )
            """)
            
            # Usage logs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS usage_logs (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    map_id TEXT,
                    action TEXT, -- 'created', 'accessed', 'updated', 'deleted'
                    user_id TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    details TEXT,
                    FOREIGN KEY (map_id) REFERENCES distribution_maps (map_id)
                )
            """)
            
            conn.commit()
    
    def add_species(self, scientific_name: str, common_name: str = None, 
                   family: str = None, habitat_type: str = None, 
                   conservation_status: str = None) -> int:
        """
        Add a new species to the database.
        
        Args:
            scientific_name: Scientific name of the species
            common_name: Common name of the species
            family: Taxonomic family
            habitat_type: Primary habitat type
            conservation_status: IUCN conservation status
            
        Returns:
            species_id: Unique identifier for the species
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                    INSERT INTO species (scientific_name, common_name, family, 
                                       habitat_type, conservation_status)
                    VALUES (?, ?, ?, ?, ?)
                """, (scientific_name, common_name, family, habitat_type, conservation_status))
                species_id = cursor.lastrowid
                conn.commit()
                return species_id
            except sqlite3.IntegrityError:
                # Species already exists, return existing ID
                cursor.execute("SELECT species_id FROM species WHERE scientific_name = ?", 
                             (scientific_name,))
                return cursor.fetchone()[0]
    
    def store_distribution_map(self, species_id: int, map_name: str, 
                             map_type: str, file_path: str, 
                             metadata: Dict[str, Any] = None) -> str:
        """
        Store a distribution map with associated metadata.
        
        Args:
            species_id: ID of the species this map represents
            map_name: Descriptive name for the map
            map_type: Type of distribution map
            file_path: Path to the map file
            metadata: Additional metadata dictionary
            
        Returns:
            map_id: Unique identifier for the stored map
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Map file not found: {file_path}")
        
        # Generate unique map ID
        map_id = str(uuid.uuid4())
        
        # Calculate file hash for integrity checking
        file_hash = self._calculate_file_hash(file_path)
        file_size = os.path.getsize(file_path)
        
        # Determine file format from extension
        file_format = Path(file_path).suffix.lower().lstrip('.')
        
        # Copy file to storage location
        file_extension = Path(file_path).suffix
        map_type_dir = self.storage_root / f"{map_type}_maps"
        map_type_dir.mkdir(exist_ok=True)  # Ensure directory exists
        stored_file_path = map_type_dir / f"{map_id}{file_extension}"
        shutil.copy2(file_path, stored_file_path)
        
        # Extract spatial information if possible
        spatial_extent = self._extract_spatial_extent(file_path)
        coordinate_system = metadata.get('coordinate_system', 'WGS84') if metadata else 'WGS84'
        resolution = metadata.get('resolution') if metadata else None
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Insert main map record
            cursor.execute("""
                INSERT INTO distribution_maps (
                    map_id, species_id, map_name, map_type, file_format,
                    file_path, file_size, file_hash, spatial_extent,
                    coordinate_system, resolution, prediction_algorithm,
                    accuracy_score, validation_method, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                map_id, species_id, map_name, map_type, file_format,
                str(stored_file_path), file_size, file_hash, 
                json.dumps(spatial_extent) if spatial_extent else None,
                coordinate_system, resolution,
                metadata.get('algorithm') if metadata else None,
                metadata.get('accuracy') if metadata else None,
                metadata.get('validation_method') if metadata else None,
                metadata.get('created_by', 'system') if metadata else 'system'
            ))
            
            # Store additional metadata
            if metadata:
                for key, value in metadata.items():
                    if key not in ['coordinate_system', 'resolution', 'algorithm', 
                                 'accuracy', 'validation_method', 'created_by']:
                        data_type = self._infer_data_type(value)
                        cursor.execute("""
                            INSERT INTO map_metadata (map_id, attribute_name, 
                                                    attribute_value, data_type)
                            VALUES (?, ?, ?, ?)
                        """, (map_id, key, str(value), data_type))
            
            # Log the creation
            cursor.execute("""
                INSERT INTO usage_logs (map_id, action, user_id, details)
                VALUES (?, 'created', ?, ?)
            """, (map_id, metadata.get('created_by', 'system') if metadata else 'system',
                  f"Map '{map_name}' created for species ID {species_id}"))
            
            conn.commit()
        
        return map_id
    
    def query_maps(self, species_id: int = None, map_type: str = None,
                  min_accuracy: float = None, limit: int = None) -> pd.DataFrame:
        """
        Query distribution maps based on various criteria.
        
        Args:
            species_id: Filter by species ID
            map_type: Filter by map type
            min_accuracy: Minimum accuracy score
            limit: Maximum number of results
            
        Returns:
            DataFrame containing matching maps
        """
        query = """
            SELECT dm.*, s.scientific_name, s.common_name
            FROM distribution_maps dm
            LEFT JOIN species s ON dm.species_id = s.species_id
            WHERE dm.status = 'active'
        """
        params = []
        
        if species_id:
            query += " AND dm.species_id = ?"
            params.append(species_id)
        
        if map_type:
            query += " AND dm.map_type = ?"
            params.append(map_type)
        
        if min_accuracy:
            query += " AND dm.accuracy_score >= ?"
            params.append(min_accuracy)
        
        query += " ORDER BY dm.created_at DESC"
        
        if limit:
            query += " LIMIT ?"
            params.append(limit)
        
        with sqlite3.connect(self.db_path) as conn:
            df = pd.read_sql_query(query, conn, params=params)
            
            # Log access
            if not df.empty:
                cursor = conn.cursor()
                for map_id in df['map_id'].values:
                    cursor.execute("""
                        INSERT INTO usage_logs (map_id, action, user_id, details)
                        VALUES (?, 'accessed', 'query_user', 'Map queried')
                    """, (map_id,))
                conn.commit()
        
        return df
    
    def get_map_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics about stored maps."""
        with sqlite3.connect(self.db_path) as conn:
            stats = {}
            
            # Total maps
            stats['total_maps'] = pd.read_sql_query(
                "SELECT COUNT(*) as count FROM distribution_maps WHERE status = 'active'", 
                conn
            ).iloc[0]['count']
            
            # Maps by type
            stats['maps_by_type'] = pd.read_sql_query("""
                SELECT map_type, COUNT(*) as count 
                FROM distribution_maps 
                WHERE status = 'active'
                GROUP BY map_type
            """, conn).to_dict('records')
            
            # Maps by species
            stats['maps_by_species'] = pd.read_sql_query("""
                SELECT s.scientific_name, s.common_name, COUNT(dm.map_id) as map_count
                FROM species s
                LEFT JOIN distribution_maps dm ON s.species_id = dm.species_id
                WHERE dm.status = 'active' OR dm.status IS NULL
                GROUP BY s.species_id
                ORDER BY map_count DESC
            """, conn).to_dict('records')
            
            # Storage usage
            total_size = pd.read_sql_query("""
                SELECT SUM(file_size) as total_size FROM distribution_maps WHERE status = 'active'
            """, conn).iloc[0]['total_size']
            stats['total_storage_mb'] = round(total_size / (1024*1024), 2) if total_size else 0
            
            # Average accuracy
            avg_accuracy = pd.read_sql_query("""
                SELECT AVG(accuracy_score) as avg_accuracy 
                FROM distribution_maps 
                WHERE status = 'active' AND accuracy_score IS NOT NULL
            """, conn).iloc[0]['avg_accuracy']
            stats['average_accuracy'] = round(avg_accuracy, 3) if avg_accuracy else None
            
        return stats
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of a file."""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()
    
    def _extract_spatial_extent(self, file_path: str) -> Dict[str, float]:
        """Extract spatial extent from a map file (simplified version)."""
        # This is a simplified implementation
        # In a real system, you would use GDAL/rasterio to extract actual bounds
        return {
            "min_x": -180.0,
            "max_x": 180.0,
            "min_y": -90.0,
            "max_y": 90.0
        }
    
    def _infer_data_type(self, value: Any) -> str:
        """Infer data type of a value."""
        if isinstance(value, bool):
            return 'boolean'
        elif isinstance(value, (int, float)):
            return 'numeric'
        elif isinstance(value, (dict, list)):
            return 'json'
        else:
            return 'string'
    
    def export_metadata(self, output_path: str, format: str = 'csv'):
        """Export all metadata to a file."""
        with sqlite3.connect(self.db_path) as conn:
            query = """
                SELECT 
                    dm.map_id,
                    dm.map_name,
                    s.scientific_name,
                    s.common_name,
                    dm.map_type,
                    dm.file_format,
                    dm.accuracy_score,
                    dm.created_at,
                    dm.prediction_algorithm
                FROM distribution_maps dm
                LEFT JOIN species s ON dm.species_id = s.species_id
                WHERE dm.status = 'active'
                ORDER BY dm.created_at DESC
            """
            df = pd.read_sql_query(query, conn)
            
            if format.lower() == 'csv':
                df.to_csv(output_path, index=False)
            elif format.lower() == 'json':
                df.to_json(output_path, orient='records', indent=2)
            
        return len(df)

    def close(self):
        """Clean up resources."""
        pass


if __name__ == "__main__":
    # Example usage
    storage = DistributionMapStorage()
    print("Distribution Map Storage System initialized successfully!")
    print(f"Database: {storage.db_path}")
    print(f"Storage root: {storage.storage_root}")