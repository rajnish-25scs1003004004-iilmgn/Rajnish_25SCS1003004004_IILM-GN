"""
Wildlife Distribution Map Storage System - Demonstration
======================================================

This script demonstrates the capabilities of the distribution map storage system
by creating sample data, storing maps, and generating visualizations.

Author: Your Name
Course: CSE-UCS-1002 - Introduction to AI-ML
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
import os
from datetime import datetime, timedelta
from distribution_map_storage import DistributionMapStorage
import random


class MapStorageDemo:
    """Demonstration class for the wildlife distribution map storage system."""
    
    def __init__(self, output_dir: str = "../output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Initialize storage system
        db_path = self.output_dir / "wildlife_maps_demo.db"
        storage_path = self.output_dir / "map_storage"
        
        self.storage = DistributionMapStorage(
            db_path=str(db_path),
            storage_root=str(storage_path)
        )
        
        # Set up matplotlib for better plots
        plt.style.use('default')
        sns.set_palette("husl")
        
    def create_sample_species(self):
        """Create sample species data for demonstration."""
        species_data = [
            {
                'scientific_name': 'Panthera leo',
                'common_name': 'African Lion',
                'family': 'Felidae',
                'habitat_type': 'Savanna',
                'conservation_status': 'Vulnerable'
            },
            {
                'scientific_name': 'Loxodonta africana',
                'common_name': 'African Elephant',
                'family': 'Elephantidae',
                'habitat_type': 'Savanna/Forest',
                'conservation_status': 'Endangered'
            },
            {
                'scientific_name': 'Acinonyx jubatus',
                'common_name': 'Cheetah',
                'family': 'Felidae',
                'habitat_type': 'Grassland',
                'conservation_status': 'Vulnerable'
            },
            {
                'scientific_name': 'Diceros bicornis',
                'common_name': 'Black Rhinoceros',
                'family': 'Rhinocerotidae',
                'habitat_type': 'Savanna',
                'conservation_status': 'Critically Endangered'
            },
            {
                'scientific_name': 'Giraffa camelopardalis',
                'common_name': 'Giraffe',
                'family': 'Giraffidae',
                'habitat_type': 'Savanna',
                'conservation_status': 'Vulnerable'
            }
        ]
        
        species_ids = {}
        for species in species_data:
            species_id = self.storage.add_species(**species)
            species_ids[species['scientific_name']] = species_id
            print(f"Added species: {species['common_name']} (ID: {species_id})")
        
        return species_ids
    
    def generate_sample_map_files(self):
        """Generate sample map files for demonstration."""
        data_dir = Path("../data")
        data_dir.mkdir(exist_ok=True)
        
        map_files = []
        
        # Generate different types of distribution maps
        map_types = ['habitat_suitability', 'presence_probability', 'corridor_prediction']
        
        for i, map_type in enumerate(map_types):
            for j in range(2):  # 2 maps per type
                # Create a simple CSV file representing a grid-based map
                filename = f"{map_type}_map_{i}_{j}.csv"
                filepath = data_dir / filename
                
                # Generate synthetic distribution data
                size = 50  # 50x50 grid
                x_coords = np.linspace(0, 10, size)
                y_coords = np.linspace(0, 10, size)
                
                # Create mesh grid
                X, Y = np.meshgrid(x_coords, y_coords)
                
                # Generate realistic distribution patterns
                if map_type == 'habitat_suitability':
                    # Higher suitability in center, decreasing towards edges
                    center_x, center_y = 5, 5
                    Z = np.exp(-((X - center_x)**2 + (Y - center_y)**2) / (2 * (2 + j)**2))
                elif map_type == 'presence_probability':
                    # Multiple hotspots
                    Z = np.zeros_like(X)
                    for _ in range(3 + j):
                        cx, cy = random.uniform(2, 8), random.uniform(2, 8)
                        Z += np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * 1.5**2))
                    Z = Z / Z.max()  # Normalize to [0, 1]
                else:  # corridor_prediction
                    # Linear corridors
                    Z = np.exp(-np.abs(Y - (X * 0.5 + 2 + j)) / 1.5)
                
                # Add some noise
                Z += np.random.normal(0, 0.1, Z.shape)
                Z = np.clip(Z, 0, 1)
                
                # Save as CSV
                df = pd.DataFrame({
                    'x': X.flatten(),
                    'y': Y.flatten(),
                    'value': Z.flatten()
                })
                df.to_csv(filepath, index=False)
                
                map_files.append({
                    'filepath': str(filepath),
                    'map_type': map_type,
                    'filename': filename
                })
        
        return map_files
    
    def store_sample_maps(self, species_ids, map_files):
        """Store sample maps in the database."""
        algorithms = ['MaxEnt', 'Random Forest', 'Neural Network', 'SVM', 'Ensemble']
        validation_methods = ['Cross-validation', 'Hold-out', 'Bootstrap', 'Spatial block']
        
        stored_maps = []
        
        for i, map_file in enumerate(map_files):
            # Randomly assign to species
            species_name = random.choice(list(species_ids.keys()))
            species_id = species_ids[species_name]
            
            # Create metadata
            metadata = {
                'algorithm': random.choice(algorithms),
                'accuracy': round(random.uniform(0.75, 0.95), 3),
                'validation_method': random.choice(validation_methods),
                'coordinate_system': 'WGS84',
                'resolution': 1.0,  # km per grid cell
                'created_by': 'Demo System',
                'environmental_variables': json.dumps([
                    'temperature', 'precipitation', 'elevation', 'land_cover'
                ]),
                'model_parameters': json.dumps({
                    'n_estimators': random.randint(100, 500),
                    'max_depth': random.randint(5, 15)
                }),
                'training_samples': random.randint(500, 2000),
                'validation_auc': round(random.uniform(0.8, 0.95), 3)
            }
            
            # Store the map
            map_id = self.storage.store_distribution_map(
                species_id=species_id,
                map_name=f"{map_file['map_type'].replace('_', ' ').title()} - {species_name.split()[-1]}",
                map_type=map_file['map_type'],
                file_path=map_file['filepath'],
                metadata=metadata
            )
            
            stored_maps.append({
                'map_id': map_id,
                'species_name': species_name,
                'map_type': map_file['map_type'],
                'accuracy': metadata['accuracy']
            })
            
            print(f"Stored map: {map_id} for {species_name}")
        
        return stored_maps
    
    def generate_visualizations(self):
        """Generate comprehensive visualizations of the storage system."""
        # Get statistics
        stats = self.storage.get_map_statistics()
        print("\n=== Storage System Statistics ===")
        print(f"Total Maps: {stats['total_maps']}")
        print(f"Total Storage: {stats['total_storage_mb']} MB")
        print(f"Average Accuracy: {stats['average_accuracy']}")
        
        # Create visualization plots
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Wildlife Distribution Map Storage System - Analytics Dashboard', 
                    fontsize=16, fontweight='bold')
        
        # 1. Maps by Type
        ax1 = axes[0, 0]
        if stats['maps_by_type']:
            types = [item['map_type'] for item in stats['maps_by_type']]
            counts = [item['count'] for item in stats['maps_by_type']]
            
            bars = ax1.bar(types, counts, color=['#FF6B6B', '#4ECDC4', '#45B7D1'])
            ax1.set_title('Distribution Maps by Type', fontweight='bold')
            ax1.set_ylabel('Number of Maps')
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                ax1.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}', ha='center', va='bottom')
            
            plt.setp(ax1.get_xticklabels(), rotation=45, ha='right')
        
        # 2. Species Distribution
        ax2 = axes[0, 1]
        if stats['maps_by_species']:
            species_data = [s for s in stats['maps_by_species'] if s['map_count'] > 0]
            if species_data:
                species_names = [s['common_name'] or s['scientific_name'] 
                               for s in species_data[:5]]  # Top 5
                map_counts = [s['map_count'] for s in species_data[:5]]
                
                bars = ax2.barh(species_names, map_counts, color='#96CEB4')
                ax2.set_title('Maps per Species (Top 5)', fontweight='bold')
                ax2.set_xlabel('Number of Maps')
                
                # Add value labels
                for i, bar in enumerate(bars):
                    width = bar.get_width()
                    ax2.text(width, bar.get_y() + bar.get_height()/2.,
                            f'{int(width)}', ha='left', va='center')
        
        # 3. Accuracy Distribution
        ax3 = axes[1, 0]
        # Query all maps to get accuracy data
        all_maps = self.storage.query_maps()
        if not all_maps.empty and 'accuracy_score' in all_maps.columns:
            accuracy_data = all_maps['accuracy_score'].dropna()
            if len(accuracy_data) > 0:
                ax3.hist(accuracy_data, bins=10, color='#FFB74D', alpha=0.7, edgecolor='black')
                ax3.set_title('Model Accuracy Distribution', fontweight='bold')
                ax3.set_xlabel('Accuracy Score')
                ax3.set_ylabel('Frequency')
                ax3.axvline(accuracy_data.mean(), color='red', linestyle='--', 
                           label=f'Mean: {accuracy_data.mean():.3f}')
                ax3.legend()
        
        # 4. Storage Usage Over Time
        ax4 = axes[1, 1]
        if not all_maps.empty:
            # Convert created_at to datetime and aggregate by date
            all_maps['created_at'] = pd.to_datetime(all_maps['created_at'])
            daily_counts = all_maps.set_index('created_at').resample('D').size().cumsum()
            
            ax4.plot(daily_counts.index, daily_counts.values, 
                    marker='o', color='#9B59B6', linewidth=2)
            ax4.set_title('Cumulative Maps Stored Over Time', fontweight='bold')
            ax4.set_xlabel('Date')
            ax4.set_ylabel('Total Maps')
            ax4.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        
        # Save the plot
        viz_path = self.output_dir / "storage_system_analytics.png"
        plt.savefig(viz_path, dpi=300, bbox_inches='tight')
        print(f"\nVisualization saved: {viz_path}")
        
        # Create a detailed map type analysis
        self._create_map_type_analysis()
        
        return viz_path
    
    def _create_map_type_analysis(self):
        """Create detailed analysis of different map types."""
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        fig.suptitle('Distribution Map Types - Detailed Analysis', fontsize=16, fontweight='bold')
        
        map_types = ['habitat_suitability', 'presence_probability', 'corridor_prediction']
        colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']
        
        for i, (map_type, color) in enumerate(zip(map_types, colors)):
            ax = axes[i]
            
            # Query maps of this type
            maps = self.storage.query_maps(map_type=map_type)
            
            if not maps.empty:
                # Create accuracy vs creation time plot
                maps['created_at'] = pd.to_datetime(maps['created_at'])
                
                scatter = ax.scatter(maps['created_at'], maps['accuracy_score'], 
                                   c=color, alpha=0.7, s=100)
                
                ax.set_title(f'{map_type.replace("_", " ").title()}', fontweight='bold')
                ax.set_xlabel('Creation Date')
                ax.set_ylabel('Accuracy Score')
                ax.set_ylim(0.7, 1.0)
                
                # Add trend line
                if len(maps) > 1:
                    z = np.polyfit(range(len(maps)), maps['accuracy_score'], 1)
                    p = np.poly1d(z)
                    ax.plot(maps['created_at'], p(range(len(maps))), 
                           color='red', linestyle='--', alpha=0.8)
                
                # Add statistics text
                mean_acc = maps['accuracy_score'].mean()
                ax.text(0.05, 0.95, f'Mean Accuracy: {mean_acc:.3f}', 
                       transform=ax.transAxes, verticalalignment='top',
                       bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
        
        plt.tight_layout()
        
        analysis_path = self.output_dir / "map_type_analysis.png"
        plt.savefig(analysis_path, dpi=300, bbox_inches='tight')
        print(f"Map type analysis saved: {analysis_path}")
        
        return analysis_path
    
    def export_data(self):
        """Export system data for analysis."""
        # Export metadata
        metadata_path = self.output_dir / "map_metadata.csv"
        count = self.storage.export_metadata(str(metadata_path), format='csv')
        print(f"\nExported metadata for {count} maps to: {metadata_path}")
        
        # Export statistics as JSON
        stats = self.storage.get_map_statistics()
        stats_path = self.output_dir / "system_statistics.json"
        with open(stats_path, 'w') as f:
            json.dump(stats, f, indent=2, default=str)
        print(f"Exported statistics to: {stats_path}")
        
        return metadata_path, stats_path
    
    def generate_sample_queries(self):
        """Demonstrate various query capabilities."""
        print("\n=== Sample Queries Demonstration ===")
        
        # Query 1: All habitat suitability maps
        habitat_maps = self.storage.query_maps(map_type='habitat_suitability')
        print(f"\n1. Habitat Suitability Maps: {len(habitat_maps)} found")
        if not habitat_maps.empty:
            print(habitat_maps[['map_name', 'scientific_name', 'accuracy_score']].head())
        
        # Query 2: High accuracy maps (>0.85)
        high_acc_maps = self.storage.query_maps(min_accuracy=0.85)
        print(f"\n2. High Accuracy Maps (>0.85): {len(high_acc_maps)} found")
        if not high_acc_maps.empty:
            print(high_acc_maps[['map_name', 'accuracy_score', 'prediction_algorithm']].head())
        
        # Query 3: Maps for endangered species
        all_maps = self.storage.query_maps()
        if not all_maps.empty:
            # This would require joining with species conservation status
            print(f"\n3. Total Active Maps: {len(all_maps)}")
            print("Sample of recent maps:")
            print(all_maps[['map_name', 'map_type', 'created_at']].head())
    
    def run_complete_demo(self):
        """Run the complete demonstration."""
        print("🚀 Starting Wildlife Distribution Map Storage System Demo")
        print("=" * 60)
        
        # Step 1: Create sample species
        print("\n📊 Step 1: Creating sample species...")
        species_ids = self.create_sample_species()
        
        # Step 2: Generate sample map files
        print("\n🗺️  Step 2: Generating sample map files...")
        map_files = self.generate_sample_map_files()
        print(f"Generated {len(map_files)} sample map files")
        
        # Step 3: Store maps in database
        print("\n💾 Step 3: Storing maps in database...")
        stored_maps = self.store_sample_maps(species_ids, map_files)
        
        # Step 4: Generate visualizations
        print("\n📈 Step 4: Generating visualizations...")
        viz_path = self.generate_visualizations()
        
        # Step 5: Demonstrate queries
        print("\n🔍 Step 5: Demonstrating query capabilities...")
        self.generate_sample_queries()
        
        # Step 6: Export data
        print("\n📤 Step 6: Exporting data...")
        metadata_path, stats_path = self.export_data()
        
        print("\n✅ Demo completed successfully!")
        print(f"📊 Database: {self.storage.db_path}")
        print(f"📁 Storage: {self.storage.storage_root}")
        print(f"📈 Visualizations: {self.output_dir}")
        
        return {
            'database_path': self.storage.db_path,
            'storage_path': self.storage.storage_root,
            'output_path': self.output_dir,
            'maps_stored': len(stored_maps),
            'species_count': len(species_ids)
        }


if __name__ == "__main__":
    # Run the demonstration
    demo = MapStorageDemo()
    results = demo.run_complete_demo()
    
    print(f"\n🎉 Demo Results Summary:")
    print(f"   • {results['maps_stored']} maps stored")
    print(f"   • {results['species_count']} species added")
    print(f"   • Database: {results['database_path']}")
    print(f"   • Files: {results['storage_path']}")
    print(f"   • Output: {results['output_path']}")